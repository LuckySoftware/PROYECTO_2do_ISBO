/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_2do_isbo;

/**
 *
 * @author ilucky
 */
public class PROYECTO_2do_ISBO {

    public static void main(String[] args) 
    {
        // VENTANA DE INICIO DE SESION
        Inicio ventanaInicio = new Inicio();
        ventanaInicio.setVisible(true);
        
        Registro ventanaRegistro = new Registro();
        ventanaRegistro.setVisible(false);
    }
}
